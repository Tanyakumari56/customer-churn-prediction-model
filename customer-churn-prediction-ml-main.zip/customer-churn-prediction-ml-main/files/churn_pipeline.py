import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier
import lightgbm as lgb

# ===============================
# STEP 1 — LOAD DATA
# ===============================
train = pd.read_csv("customer_churn_dataset-training-master.csv")
test  = pd.read_csv("customer_churn_dataset-testing-master.csv")

# Drop ID
train.drop("CustomerID", axis=1, inplace=True)
test.drop("CustomerID", axis=1, inplace=True)

# ===============================
# STEP 2 — FEATURE ENGINEERING
# ===============================
for df in [train, test]:
    df["Spend_Per_Tenure"] = df["Total Spend"] / (df["Tenure"] + 1)
    df["Spend_Per_Usage"] = df["Total Spend"] / (df["Usage Frequency"] + 1)
    df["Support_Per_Tenure"] = df["Support Calls"] / (df["Tenure"] + 1)
    df["Support_Per_Usage"] = df["Support Calls"] / (df["Usage Frequency"] + 1)
    df["Delay_Per_Tenure"] = df["Payment Delay"] / (df["Tenure"] + 1)
    df["Interaction_Rate"] = df["Last Interaction"] / (df["Tenure"] + 1)

# ===============================
# STEP 3 — ENCODING
# ===============================
le_gender = LabelEncoder()
train["Gender"] = le_gender.fit_transform(train["Gender"])
test["Gender"]  = le_gender.transform(test["Gender"])

train = pd.get_dummies(train, columns=["Subscription Type", "Contract Length"])
test  = pd.get_dummies(test, columns=["Subscription Type", "Contract Length"])

# Align columns
train, test = train.align(test, join="left", axis=1, fill_value=0)

# ===============================
# STEP 4 — SPLIT DATA
# ===============================
X = train.drop("Churn", axis=1)
y = train["Churn"]

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# ===============================
# STEP 5 — CLASS IMBALANCE
# ===============================
neg, pos = np.bincount(y_train.astype(int))
scale_pos_weight = neg / pos

# ===============================
# STEP 6 — XGBOOST TUNING
# ===============================
param_grid = {
    "n_estimators": [400, 600, 800],
    "max_depth": [4, 5, 6, 7],
    "learning_rate": [0.01, 0.03, 0.05],
    "subsample": [0.7, 0.8, 0.9],
    "colsample_bytree": [0.7, 0.8, 0.9],
    "gamma": [0, 0.1, 0.2],
    "reg_lambda": [1, 1.5, 2]
}

xgb = XGBClassifier(
    objective="binary:logistic",
    eval_metric="auc",
    tree_method="hist",
    scale_pos_weight=scale_pos_weight,
    random_state=42
)

search = RandomizedSearchCV(
    xgb,
    param_grid,
    n_iter=15,
    scoring="roc_auc",
    cv=3,
    verbose=1,
    n_jobs=-1
)

search.fit(X_train, y_train)
best_xgb = search.best_estimator_

# ===============================
# STEP 7 — LIGHTGBM
# ===============================
lgb_model = lgb.LGBMClassifier(
    n_estimators=800,
    learning_rate=0.03,
    subsample=0.85,
    colsample_bytree=0.85
)

lgb_model.fit(X_train, y_train)

# ===============================
# STEP 8 — EVALUATION
# ===============================
xgb_auc = roc_auc_score(y_val, best_xgb.predict_proba(X_val)[:,1])
lgb_auc = roc_auc_score(y_val, lgb_model.predict_proba(X_val)[:,1])

print("XGBoost ROC-AUC:", xgb_auc)
print("LightGBM ROC-AUC:", lgb_auc)

# Select best model
best_model = best_xgb if xgb_auc > lgb_auc else lgb_model

# ===============================
# STEP 9 — SAVE MODEL
# ===============================
pickle.dump(best_model, open("best_churn_model.pkl", "wb"))
pickle.dump(le_gender, open("label_encoder_gender.pkl", "wb"))
pickle.dump(X.columns, open("feature_columns.pkl", "wb"))

print("Model saved successfully")