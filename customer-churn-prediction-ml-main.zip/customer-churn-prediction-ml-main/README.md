# customer-churn-prediction-ml
End-to-end machine learning project for customer churn prediction using Python, XGBoost, and FastAPI with ROC-AUC evaluation and deployment.
